import sharp from 'sharp';
import fs from 'fs';

const imgPath = 'fbtool.net.png';
const folderPath = '.';
const prefix = 'smt-';
const suffix = '-filled';
const sizes = [150,128,64,50,48,44,38,32,19,16];

const resize = (imgSize: number, prefix: string, suffix: string) =>{
    sharp(imgPath)
        .resize(imgSize)
        .toFile(`${folderPath}/${prefix}${imgSize}${suffix}.png`, function (err) {
        });
}


if (!fs.existsSync(folderPath)){
    fs.mkdirSync(folderPath)
}
try {
    sizes.forEach(size => {
        resize(size, prefix, suffix)
    })
    console.log(`Resizer has loaded images here: ${folderPath} `)
} catch (err) {
    console.error(err);
}